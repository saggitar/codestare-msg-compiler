def some_utility_function():
    return "Wow"
